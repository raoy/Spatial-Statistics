library(ggplot2)
library(gstat)
library(sp)
library(maptools)

#mengimpor data dari format .csv
nikel1<-read.csv("D:/Dept.STK/Statistika Spasial (S2)/Praktikum (RA)/Interpolation/database_Nickel.csv",sep=",",header=T)
nikel<-nikel1
coordinates(nikel) = ~XCOLLAR + YCOLLAR
plot(nikel)

#membuat data grid
x.range <- as.numeric(c(min(nikel$XCOLLAR), max(nikel$XCOLLAR)))  # min/max longitude of the interpolation area
y.range <- as.numeric(c(min(nikel$YCOLLAR), max(nikel$YCOLLAR)))  # min/max latitude of the interpolation area

grd <- expand.grid(x = seq(from = x.range[1], to = x.range[2], by = 1), y = seq(from = y.range[1],
    to = y.range[2], by = 1))  # expand points to grid
coordinates(grd) <- ~x + y
gridded(grd) <- TRUE

plot(grd, cex = 1.5, col = "grey")
points(nikel, pch = 1, col = "red", cex = 1)

#melakukan interpolasi dengan Inverse Distance Weighted
ni.idw = idw(Ni ~ 1, nikel, grd)

idw.out = as.data.frame(ni.idw)  # output is defined as a data table
names(idw.out)[1:3] <- c("long", "lat", "var1.pred")  # give names to the modelled variables

ggplot() + geom_tile(data = idw.out, aes(x = long, y = lat, fill = var1.pred)) +
    geom_point(data = nikel1, aes(x = XCOLLAR, y = YCOLLAR), shape = 21,
        colour = "red")

#evaluating IDW interpolation
ni.idwcv<-krige.cv(Ni ~ 1, nikel)
RMSE.idw<-sqrt(sum(ni.idwcv$residual^2)/length(ni.idwcv$residual))





