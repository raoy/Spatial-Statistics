library(raster)
setwd("D:/Dept.STK/Statistika Spasial (S2)/TA 2018-2019/mid-test LAB SESSION")
city <- readRDS('city.rds')

library(maptools)
w<-as(city,"owin")

library(spatstat)
datacrime<-read.csv("datacrime.csv", sep=",", header=T)

crime.ppp<-ppp(datacrime$long, datacrime$lat,window=w ,marks=datacrime$CATEGORY)


